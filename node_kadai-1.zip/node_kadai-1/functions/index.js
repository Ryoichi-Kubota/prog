const functions = require("firebase-functions");

// Expressの読み込み
const express = require("express");
const requestPromise = require("request-promise-native"); // 追加
// const cors = require("cors"); // 追加

const app = express();

// app.use(cors());  // 一旦コメントアウト

// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//     functions.logger.info("Hello logs!", { structuredData: true });
//     response.send("Hello from Firebase!");
// });

// APIにリクエストを送る関数を定義
const getDataFromApi = async (keyword) => {
    // cloud functionsから実行する場合には地域の設定が必要になるため，`country=JP`を追加している
    const requestUrl =
        "https://www.googleapis.com/books/v1/volumes?country=JP&q=intitle:";
    const result = await requestPromise(`${requestUrl}${keyword}`);
    return result;
};

// //エンドポイントを指定
// app.get("/hello", (req, res) => {
//     // レスポンスの設定
//     res.send("Hello Express!");
// });

// // ↓↓↓ エンドポイントを追加 ↓↓↓
// app.get("/user/:userId", (req, res) => {
//     const users = [
//         { id: 1, name: "ジョナサン" },
//         { id: 2, name: "ジョセフ" },
//         { id: 3, name: "承太郎" },
//         { id: 4, name: "仗助" },
//         { id: 5, name: "ジョルノ" },
//     ];
//     // req.params.userIdでURLの後ろにつけた値をとれる．
//     const targetUser = users.find(
//         (user) => user.id === Number(req.params.userId)
//     );
//     res.send(targetUser);
// });

// // エンドポイント追加
// app.get("/gbooks/:keyword", cors(), async (req, res) => {
// app.get("/gbooks/:keyword", async (req, res) => {
//     // APIリクエストの関数を実行
//     const response = await getDataFromApi(req.params.keyword);
//     res.send(response);
// });

// 出力
const api = functions.https.onRequest(app);
module.exports = { api };

// http://localhost:5000/gs-exp-node/us-central1/helloWorld

// https://us-central1-gs-exp-node.cloudfunctions.net/helloWorld

// sendgrid用
const sgMail = require('@sendgrid/mail')

app.get("/mail", async (req, res) => {
    // exports.sendMail = functions.https.onRequest(async (req, res) => {
    sgMail.setApiKey("xxxx")//←sendgirdで生成したApi Key 

    res.set('Access-Control-Allow-Origin', '*');
    const msg = {
        to: req.query.tomail, //←送信先メールアドレス
        from: req.query.frommail, //←送信元メールアドレス
        subject: `${req.query.name}様からの問い合わせ`,
        html: `<strong>ここに問い合わせ内容が入ります</strong>`,
    }
    sgMail
        .send(msg)
        .then(() => {
            res.send('成功')
        })
        .catch((error) => {
            res.send('失敗', error)
        })
});

// firebase serve後、ターミナルまたはブラウザから以下のURLを打つとメールが送れます
// http://localhost:5000/gs-exp-node/us-central1/api/mail?tomail=xx送信先メールアドレスxx@xxxx.com&from=xx送信元メールアドレスxx@xxxx.com&name=xx送信者の名前xx

